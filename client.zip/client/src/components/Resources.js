import React from 'react'

function Resources() {
    return (
        <div>
            <h1>Resources here</h1>
        </div>
    )
}

export default Resources

